---
name: Bug report
about: Report an issue with this library
---
<!-- Please search existing issues and discussions to avoid creating duplicates. -->

- OpenPGP.js version:
- Affected platform (Browser or Node.js version):

<!-- Describe the bug you have encountered -->