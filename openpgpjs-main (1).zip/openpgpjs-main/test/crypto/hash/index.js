module.exports = () => describe('Hash', function () {
  require('./md5.js')();
  require('./ripemd.js')();
  require('./sha.js')();
});
