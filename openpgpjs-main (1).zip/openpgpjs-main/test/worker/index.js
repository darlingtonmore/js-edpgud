module.exports = () => describe('Web Worker', function () {
  require('./application_worker.js')();
});

